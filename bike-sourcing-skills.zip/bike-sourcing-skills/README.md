# Bike Manufacturer Multi-Agent Sourcing Skills

Complete Skills package for sourcing 35+ parts across multiple bike models, from multiple suppliers, with cost and lead-time optimization.

## Quick Start

1. **Start here:** `documentation/00_START_HERE.md`
2. **Understand the system:** `documentation/BIKE_SOURCING_SUMMARY.md`
3. **Read the skills:** All files in `skills/` folder
4. **Reference data:** All files in `reference-data/` folder

## What's Inside

### Skills (The Agent Instructions)

These are markdown files that teach Claude how to make sourcing decisions:

- **`bom-structure.md`** — Bike models, parts catalog, criticality matrix, assembly constraints
- **`cost-optimizer.md`** — Landed cost calculation, BOM aggregation, cost optimization
- **`lead-time-critical-path.md`** — Critical path analysis, bottleneck identification, timeline checking
- **`sourcing-recommendation.md`** — Output memo format, professional presentation

Total: ~1,300 lines of detailed instruction

### Documentation

- **`00_START_HERE.md`** — 5-minute orientation (read this first)
- **`BIKE_SOURCING_SUMMARY.md`** — Complete system overview
- **`SKILLS_README.md`** — How the skills work together
- **`FINAL_DELIVERABLES.txt`** — One-page summary

### Reference Data

Reference tables for sourcing calculations:

- **`duty_rates.csv`** — Import duty by HS code and country
- **`freight_rates.csv`** — Shipping costs by route and mode
- **`fx_rates.csv`** — Fixed exchange rates (Aug 2026)
- **`incoterm_rules.md`** — Cost allocation rules (FOB, CIF, DDP, etc.)
- **`supplier_master.csv`** — Sample supplier profiles

## The System

This is a **multi-agent sourcing system** for Track 03 Specialist Swarm hackathon.

**Architecture:**
```
Coordinator Agent
  ├→ Cost Specialist (cost-optimizer.md)
  │  "Find the cheapest sourcing plan"
  ├→ Lead-Time Specialist (lead-time-critical-path.md)
  │  "Check if we hit the deadline"
  └→ Output Formatter (sourcing-recommendation.md)
     "Format as professional memo"
```

**Use Case:**
- Bike manufacturer sources 35+ parts from 12 suppliers
- Three bike models (Commuter, Mountain, Road)
- Each order has volume, deadline, and supplier quotes
- System finds cheapest plan that's on-time

**Output:**
- Professional sourcing memo with parts table, cost analysis, lead-time analysis, decision rationale
- Explains tradeoffs: why you picked this supplier over that one
- Ready for CFO approval

## How to Use

1. **As agent context:** Paste these Skills into Claude as system context
2. **Build a coordinator agent:** Orchestrate the three specialists
3. **Create synthetic data:** Supplier quotes, bike orders, ground truth answers
4. **Evaluate:** Run on 10–15 scenarios, measure accuracy

## The Pitch

"A bike is 35 parts from 12 suppliers. The cheapest plan might be late. The fastest might cost too much. A sourcing analyst spends a day normalizing quotes and running scenarios. Our system does it in 90 seconds: cost specialist finds cheapest, lead-time specialist confirms on-time, coordinator resolves conflicts, outputs a professional memo. Demo: 6,000 Commuter bikes, $822K cost, on-time delivery."

## Files at a Glance

```
bike-sourcing-skills/
├── README.md (this file)
├── skills/
│   ├── bom-structure.md
│   ├── cost-optimizer.md
│   ├── lead-time-critical-path.md
│   └── sourcing-recommendation.md
├── documentation/
│   ├── 00_START_HERE.md
│   ├── BIKE_SOURCING_SUMMARY.md
│   ├── SKILLS_README.md
│   └── FINAL_DELIVERABLES.txt
└── reference-data/
    ├── duty_rates.csv
    ├── freight_rates.csv
    ├── fx_rates.csv
    ├── incoterm_rules.md
    └── supplier_master.csv
```

## Next Steps

1. Extract this zip
2. Read `documentation/00_START_HERE.md`
3. Read the four skill files in `skills/` folder
4. Build your coordinator agent (use HACKATHON_CHECKLIST.md from original pack for timing)
5. Create synthetic data (suppliers, bike orders, ground truth)
6. Test end-to-end on 1–2 scenarios
7. Demo (90 seconds live run, show output memo)

---

**Questions?** Each Skill file has detailed explanations and worked examples. Start with the documentation folder.

**Ready to build?** You have 90 minutes. Good luck! 🚴
